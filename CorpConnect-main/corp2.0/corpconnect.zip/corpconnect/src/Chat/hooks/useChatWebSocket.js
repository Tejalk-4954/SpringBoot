import { useEffect, useRef } from "react";
import { Client } from "@stomp/stompjs";
import SockJS from "sockjs-client";

export const useChatWebSocket = (ticketId, onMessageReceived) => {
  const stompClientRef = useRef(null);

  useEffect(() => {
    const socket = new SockJS("http://localhost:8080/ws");
    const client = new Client({
      webSocketFactory: () => socket,
      debug: (str) => console.log(str),
      reconnectDelay: 5000,
    });

    client.onConnect = () => {
      client.subscribe(`/topic/tickets/${ticketId}`, (msg) => {
        const data = JSON.parse(msg.body);
        onMessageReceived(data);
      });
    };

    client.activate();
    stompClientRef.current = client;

    return () => client.deactivate();
  }, [ticketId]);

  const sendMessage = (payload) => {
    if (stompClientRef.current?.connected) {
      stompClientRef.current.publish({
        destination: `/app/chat.send.${ticketId}`,
        body: JSON.stringify(payload),
      });
    }
  };

  return { sendMessage };
};
