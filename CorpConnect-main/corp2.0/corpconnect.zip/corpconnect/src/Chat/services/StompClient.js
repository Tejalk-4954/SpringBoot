import { Client } from "@stomp/stompjs";
 
export const createStompClient = () =>{
  const token = localStorage.getItem("accessToken")
  new Client({
    
    brokerURL: `http://localhost:8090/ws?token${token}`,
    reconnectDelay: 3000,
    debug: (str) => console.log(str),
  })
}
  ;