import TicketAxios from "../../Axios/TicketAxios";
 
export const getChatHistory = async (ticketId) => {
  const res = await TicketAxios.get(`/api/tickets/${ticketId}/chat`);
  return res.data;
};