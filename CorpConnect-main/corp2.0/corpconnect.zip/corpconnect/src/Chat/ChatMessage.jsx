const ChatMessage = ({ message }) => {
  const isSelf = message.senderId === localStorage.getItem("userId");
 
  return (
    <div className={`flex ${isSelf ? "justify-end" : "justify-start"}`}>
      <div
        className={`max-w-[80%] px-4 py-2 rounded-xl text-sm shadow 
          ${isSelf ? "bg-indigo-500 text-white" : "bg-gray-200 text-gray-800"}
        `}
      >
        <p>{message.message}</p>
 
        <span className="text-[10px] opacity-70 block mt-1">
          {new Date(message.createdAt).toLocaleTimeString()}
        </span>
      </div>
    </div>
  );
};
export default ChatMessage;
 