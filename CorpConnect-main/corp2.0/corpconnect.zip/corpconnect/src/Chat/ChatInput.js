import React, { useState } from "react";

const ChatInput = ({ onSend, ticketId }) => {
  const [text, setText] = useState("");

  const handleSend = () => {
    if (text.trim() === "") return;
    onSend({ message: text, ticketId });
    setText("");
  };

  return (
    <div className="chat-input d-flex">
      <input
        type="text"
        value={text}
        onChange={(e) => setText(e.target.value)}
        placeholder="Type a message..."
        className="form-control"
      />
      <button className="btn btn-primary ms-2" onClick={handleSend}>
        Send
      </button>
    </div>
  );
};

export default ChatInput;
