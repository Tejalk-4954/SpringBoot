import { useEffect, useState } from "react";
import { createStompClient } from "../Chat/services/StompClient";
import { getChatHistory } from "../Chat/services/ChatServices";
 
const ChatBox = ({ ticketId }) => {
  const [messages, setMessages] = useState([]);
 
  useEffect(() => {
    let client = createStompClient();
 
    // 👉 Load chat history from REST API
    getChatHistory(ticketId).then((res) => {
      setMessages(res.data);
    });
 
    client.onConnect = () => {
      console.log("Connected to WebSocket");
 
      // 👉 Subscribe to chat topic
      client.subscribe(`/topic/ticket/${ticketId}`, (msg) => {
        const body = JSON.parse(msg.body);
 
        setMessages((prev) => [...prev, body]);
      });
    };
 
    client.onStompError = (err) => {
      console.error("STOMP ERROR:", err);
    };
 
    client.onWebSocketClose = () => {
      console.warn("WebSocket disconnected!");
    };
 
    client.activate();
 
    return () => {
      console.log("Cleaning up...");
      client.deactivate();
    };
  }, [ticketId]);
 
  return (
    <div>
      {messages.map((m, i) => (
        <div key={i}>
          {m.text}
        </div>
      ))}
    </div>
  );
};
 
export default ChatBox;
 