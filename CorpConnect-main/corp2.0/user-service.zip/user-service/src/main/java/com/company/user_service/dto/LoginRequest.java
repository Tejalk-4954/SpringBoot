package com.company.user_service.dto;

import jakarta.validation.constraints.NotBlank;

public class LoginRequest {
	  @NotBlank private String email;
	  @NotBlank private String password;
	  // getters/setters
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	  
	  
	}
