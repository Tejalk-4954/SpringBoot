package com.company.user_service.config;

import com.company.user_service.entity.Role;
import com.company.user_service.repo.RoleRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Component
public class RoleInitializer implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(RoleInitializer.class);

    private final RoleRepository roleRepository;

    public RoleInitializer(RoleRepository roleRepository) {
        this.roleRepository = roleRepository;
    }

    @Override
    public void run(String... args) {
        List<String> requiredRoles = Arrays.asList(
                "ADMIN",
                "EMPLOYEE",
                "MANAGER",
                "HR_HEAD",
                "ITS_HEAD",
                "FINANCE_HEAD",
                "IT_HEAD"
        );

        for (String roleName : requiredRoles) {
            Role existing = roleRepository.findByName(roleName);
            if (existing == null) {
                Role r = new Role();
                r.setId(UUID.randomUUID().toString());
                r.setName(roleName);
                roleRepository.save(r);
                log.info("Seeded role: {}", roleName);
            }
        }
    }
}